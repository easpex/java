
/**
 * CampaignServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:24:30 EDT)
 */
    package api.eyeblaster.com.Campaign;
    /**
     *  CampaignServiceSkeleton java skeleton for the axisService
     */
    public class CampaignServiceSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param getMarketsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetMarketsResponse GetMarkets
                  (
                  api.eyeblaster.com.message.Campaign.GetMarketsRequest getMarketsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetMarkets");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getContactRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetContactResponse GetContact
                  (
                  api.eyeblaster.com.message.Campaign.GetContactRequest getContactRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetContact");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getMonitorDeliveryRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetMonitorDeliveryResponse GetMonitorDelivery
                  (
                  api.eyeblaster.com.message.Campaign.GetMonitorDeliveryRequest getMonitorDeliveryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetMonitorDelivery");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createCampaignCustomLogRequest
         */
        
                 public void CreateCampaignCustomLog
                  (
                  api.eyeblaster.com.message.Campaign.CreateCampaignCustomLogRequest createCampaignCustomLogRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getOfficesRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetOfficesResponse GetOffices
                  (
                  api.eyeblaster.com.message.Campaign.GetOfficesRequest getOfficesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetOffices");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAgencyContactsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetAgencyContactsResponse GetAgencyContacts
                  (
                  api.eyeblaster.com.message.Campaign.GetAgencyContactsRequest getAgencyContactsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAgencyContacts");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteCampaignRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.DeleteCampaignsResponse DeleteCampaign
                  (
                  api.eyeblaster.com.message.Campaign.DeleteCampaignRequest deleteCampaignRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteCampaign");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param publishCampaignRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.PublishCampaignResponse PublishCampaign
                  (
                  api.eyeblaster.com.message.Campaign.PublishCampaignRequest publishCampaignRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#PublishCampaign");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignHistoryRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetHistoryResponse GetCampaignHistory
                  (
                  api.eyeblaster.com.message.Campaign.GetCampaignHistoryRequest getCampaignHistoryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignHistory");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCreativeShopsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetCreativeShopsResponse GetCreativeShops
                  (
                  api.eyeblaster.com.message.Campaign.GetCreativeShopsRequest getCreativeShopsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeShops");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param enableAutomaticOptimizationRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.EnableAutomaticOptimizationResponse EnableAutomaticOptimizationOnCampaign
                  (
                  api.eyeblaster.com.message.Campaign.EnableAutomaticOptimizationRequest enableAutomaticOptimizationRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#EnableAutomaticOptimizationOnCampaign");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getTargetRegionRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetTargetRegionResponse GetTargetRegionTree
                  (
                  api.eyeblaster.com.message.Campaign.GetTargetRegionRequest getTargetRegionRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetTargetRegionTree");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createContactRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.CreateContactResponse CreateContact
                  (
                  api.eyeblaster.com.message.Campaign.CreateContactRequest createContactRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateContact");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getSiteContactsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetSiteContactsResponse GetSiteContacts
                  (
                  api.eyeblaster.com.message.Campaign.GetSiteContactsRequest getSiteContactsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetSiteContacts");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryActionsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetHistoryActionsResponse GetCampaignHistoryActions
                  (
                  api.eyeblaster.com.message.Campaign.GetHistoryActionsRequest getHistoryActionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignHistoryActions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignsBasicInfoRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetCampaignsBasicInfoResponse GetCampaignsBasicInfo
                  (
                  api.eyeblaster.com.message.Campaign.GetCampaignsBasicInfoRequest getCampaignsBasicInfoRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignsBasicInfo");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAgenciesRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetAgenciesResponse GetAgencies
                  (
                  api.eyeblaster.com.message.Campaign.GetAgenciesRequest getAgenciesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAgencies");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param generateIOForCampaignRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GenerateIOForCampaignResponse GenerateIOForCampaign
                  (
                  api.eyeblaster.com.message.Campaign.GenerateIOForCampaignRequest generateIOForCampaignRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GenerateIOForCampaign");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCreativeShopRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetCreativeShopResponse GetCreativeShopContacts
                  (
                  api.eyeblaster.com.message.Campaign.GetCreativeShopRequest getCreativeShopRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeShopContacts");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateCampaignInteractionsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.UpdateCampaignInteractionsResponse UpdateCampaignInteractions
                  (
                  api.eyeblaster.com.message.Campaign.UpdateCampaignInteractionsRequest updateCampaignInteractionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateCampaignInteractions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignSitesRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetCampaignSitesResponse GetCampaignSites
                  (
                  api.eyeblaster.com.message.Campaign.GetCampaignSitesRequest getCampaignSitesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignSites");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignSiteContactsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetSiteContactsResponse GetAllSiteContacts
                  (
                  api.eyeblaster.com.message.Campaign.GetCampaignSiteContactsRequest getCampaignSiteContactsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAllSiteContacts");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdSnapRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetAdSnapResponse GetAdSnaps
                  (
                  api.eyeblaster.com.message.Campaign.GetAdSnapRequest getAdSnapRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdSnaps");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createCampaignRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.CreateCampaignResponse CreateCampaign
                  (
                  api.eyeblaster.com.message.Campaign.CreateCampaignRequest createCampaignRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateCampaign");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignInteractionsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetCampaignInteractionsResponse GetCampaignInteractions
                  (
                  api.eyeblaster.com.message.Campaign.GetCampaignInteractionsRequest getCampaignInteractionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignInteractions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateCampaignRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.UpdateCampaignResponse UpdateCampaign
                  (
                  api.eyeblaster.com.message.Campaign.UpdateCampaignRequest updateCampaignRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateCampaign");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getInteractionRelatedAdsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetInteractionRelatedAdsResponse GetInteractionRelatedAds
                  (
                  api.eyeblaster.com.message.Campaign.GetInteractionRelatedAdsRequest getInteractionRelatedAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetInteractionRelatedAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryObjectsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetHistoryObjectsResponse GetCampaignHistoryObjects
                  (
                  api.eyeblaster.com.message.Campaign.GetHistoryObjectsRequest getHistoryObjectsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignHistoryObjects");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetCampaignsResponse GetCampaigns
                  (
                  api.eyeblaster.com.message.Campaign.GetCampaignsRequest getCampaignsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaigns");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignEffectiveSettingsRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetCampaignEffectiveSettingsResponse GetCampaignEffectiveSettings
                  (
                  api.eyeblaster.com.message.Campaign.GetCampaignEffectiveSettingsRequest getCampaignEffectiveSettingsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignEffectiveSettings");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getSitesRequest
         */
        
                 public api.eyeblaster.com.message.Campaign.GetSitesResponse GetSites
                  (
                  api.eyeblaster.com.message.Campaign.GetSitesRequest getSitesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetSites");
        }
     
    }
    