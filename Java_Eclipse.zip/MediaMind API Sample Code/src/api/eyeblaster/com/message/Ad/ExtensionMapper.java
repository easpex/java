
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:25:17 EDT)
 */

            package api.eyeblaster.com.message.Ad;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SiteNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.SiteNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "UserActionAdInteractionInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.UserActionAdInteractionInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BasicInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.BasicInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdLastUpdatedOnFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdLastUpdatedOnFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdServingFilterInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdServingFilterInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BackgroundRepeatOptions".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.BackgroundRepeatOptions.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdsServiceFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdsServiceFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BaseDC".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.BaseDC.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdFormatFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdFormatFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "GetHistoryPerformedByFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.GetHistoryPerformedByFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastNonLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfInStreamVastNonLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AgencyIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AgencyIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdStatusFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdStatusFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdDimensionsFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdDimensionsFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CreativeShopIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CreativeShopIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdPanelInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdPanelInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdRejectReasons".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdRejectReasons.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastCompanionAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfInStreamVastCompanionAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CategoryIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CategoryIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AgencyNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AgencyNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/Arrays".equals(namespaceURI) &&
                  "ArrayOfint".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfint.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdAdditionalAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdAdditionalAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ResizeSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ResizeSettings.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CampaignIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CampaignIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastCompanionAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastCompanionAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SiteIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.SiteIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdAdditionalAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdAdditionalAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "EnhancedStandardBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.EnhancedStandardBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PanelFrequency".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.PanelFrequency.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "JumpTargets".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.JumpTargets.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdStatus".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdStatus.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfHistoryInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfHistoryInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "RetractType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.RetractType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdNoteInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdNoteInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ReminderPositionType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ReminderPositionType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "GetHistoryActivityDateFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.GetHistoryActivityDateFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdServingFilterInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdServingFilterInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdsServiceFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdsServiceFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SizeFilters".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.SizeFilters.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Resolution".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.Resolution.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.datacontract.org/2004/07/Eyeblaster.ACM.BusinessEntities.Lookups".equals(namespaceURI) &&
                  "LookupEnums.InstreamCompanionResourceTypesLookup".equals(typeName)){
                   
                            return  org.datacontract.schemas._2004._07.eyeblaster_acm_businessentities_lookups.LookupEnumsInstreamCompanionResourceTypesLookup.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdExtendedInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdExtendedInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CommercialBreakAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CommercialBreakAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DownloadMode".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.DownloadMode.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "APIDateTime".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.APIDateTime.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdFormat".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdFormat.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "HorizontalPositionSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.HorizontalPositionSettings.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Browser".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.Browser.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdCategoryInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdCategoryInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "StandardBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.StandardBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/Arrays".equals(namespaceURI) &&
                  "ArrayOfstring".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TimeZone".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.TimeZone.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBrowser".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfBrowser.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ActiveAdsFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ActiveAdsFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CreateLibraryAdOptions".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CreateLibraryAdOptions.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CampaignNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CampaignNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBandwidth".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfBandwidth.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAd3rdPartyTrackingURLInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAd3RdPartyTrackingURLInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "GetHistoryObjectTypeFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.GetHistoryObjectTypeFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CommercialBreakIntroPositioningType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CommercialBreakIntroPositioningType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) &&
                  "char".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization._char.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PushDownBannerInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.PushDownBannerInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "WallpaperAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.WallpaperAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ExpandableBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ExpandableBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TimerAdInteractionInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.TimerAdInteractionInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "APIFilterBase".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.Ad.APIFilterBase.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "BatchActionError".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.Ad.BatchActionError.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DisplayPeriodTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.DisplayPeriodTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PanelFrequencyType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.PanelFrequencyType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfResolution".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfResolution.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastAssetType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastAssetType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdEnabledFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdEnabledFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdPanelInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdPanelInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastCompanionAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfInStreamVastCompanionAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdClassificationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdClassificationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastNonLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastNonLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "GetHistoryFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.GetHistoryFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdInteractionInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdInteractionInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBasicInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfBasicInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastCompanionAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastCompanionAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Platform".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.Platform.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Bandwidth".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.Bandwidth.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "GetHistoryActionTypeFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.GetHistoryActionTypeFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PanelsEnabledAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.PanelsEnabledAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "ArrayOfBatchActionError".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.Ad.ArrayOfBatchActionError.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastDeliveryType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastDeliveryType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CreativeTaggingFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CreativeTaggingFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdSizeFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdSizeFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdPanelPositionType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdPanelPositionType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfPlatform".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfPlatform.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdService_AdvertiserIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdService_AdvertiserIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdCategoryInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdCategoryInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdFilterType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdFilterType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "MovementTypeSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.MovementTypeSettings.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfInStreamVastLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CreativeShopNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.CreativeShopNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ClassificationsFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ClassificationsFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "FloatingAdWithReminderInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.FloatingAdWithReminderInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PoliteBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.PoliteBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdNoteInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdNoteInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdditionalAssetsEnabledAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdditionalAssetsEnabledAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Ad3rdPartyTrackingURLInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.Ad3RdPartyTrackingURLInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.datacontract.org/2004/07/Eyeblaster.ACM.BusinessEntities.Lookups".equals(namespaceURI) &&
                  "LookupEnums.Ad3PartyTrackingURLTypeLookup".equals(typeName)){
                   
                            return  org.datacontract.schemas._2004._07.eyeblaster_acm_businessentities_lookups.LookupEnumsAd3PartyTrackingURLTypeLookup.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SingleExpandableAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.SingleExpandableAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdService_PlacementIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdService_PlacementIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdCreatedOnFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdCreatedOnFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "ListPaging".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.Ad.ListPaging.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdService_AdvertiserNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdService_AdvertiserNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdHistoryStatus".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdHistoryStatus.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ClickthroughAdInteractionInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ClickthroughAdInteractionInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "HistoryInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.HistoryInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) &&
                  "guid".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.Guid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.InStreamVastAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) &&
                  "duration".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.Duration.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SectionIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.SectionIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdPositioningType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AdPositioningType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BannerPositionType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.BannerPositionType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticEventAdInteractionInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.AutomaticEventAdInteractionInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdInteractionInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfAdInteractionInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "FloatingAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.FloatingAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfGetHistoryFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.ArrayOfGetHistoryFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "VerticalPositionSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.Ad.VerticalPositionSettings.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    