
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:25:17 EDT)
 */

            package api.eyeblaster.com.message.DeliveryGroup;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliveryGroupIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliveryGroupIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PostalCodeInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PostalCodeInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdvancedSequenceRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdvancedSequenceRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BasicInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.BasicInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TimeRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TimeRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBaseDC".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfBaseDC.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetTypeFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetTypeFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BackgroundRepeatOptions".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.BackgroundRepeatOptions.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticOptimizationMetricTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AutomaticOptimizationMetricTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BaseDC".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.BaseDC.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastNonLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfInStreamVastNonLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PlacementTypeFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PlacementTypeFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetingRetargetingInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetingRetargetingInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliveryGroupRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliveryGroupRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliveryGroupAudienceNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliveryGroupAudienceNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastCompanionAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfInStreamVastCompanionAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "LogicalOperators".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.LogicalOperators.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "EvenRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.EvenRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SubGroupWeightRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.SubGroupWeightRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAutomaticOptimizationZipCodeInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfAutomaticOptimizationZipCodeInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/Arrays".equals(namespaceURI) &&
                  "ArrayOfint".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfint.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ResizeSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ResizeSettings.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfTargetedSiteSegmentationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfTargetedSiteSegmentationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastCompanionAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.InStreamVastCompanionAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliveryGroupNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliveryGroupNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "EnhancedStandardBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.EnhancedStandardBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PanelFrequency".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PanelFrequency.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "JumpTargets".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.JumpTargets.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdStatus".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdStatus.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.InStreamVastLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ReminderPositionType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ReminderPositionType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SubGroupEvenRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.SubGroupEvenRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticOptimizationRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AutomaticOptimizationRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Resolution".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.Resolution.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.datacontract.org/2004/07/Eyeblaster.ACM.BusinessEntities.Lookups".equals(namespaceURI) &&
                  "LookupEnums.InstreamCompanionResourceTypesLookup".equals(typeName)){
                   
                            return  org.datacontract.schemas._2004._07.eyeblaster_acm_businessentities_lookups.LookupEnumsInstreamCompanionResourceTypesLookup.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdExtendedInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdExtendedInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliverySubGroupInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliverySubGroupInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CommercialBreakAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.CommercialBreakAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DownloadMode".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DownloadMode.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBehavioralTargetingInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfBehavioralTargetingInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "APIDateTime".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.APIDateTime.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TimeBasedRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TimeBasedRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfTargetAudienceInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfTargetAudienceInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "HorizontalPositionSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.HorizontalPositionSettings.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Browser".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.Browser.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "StandardBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.StandardBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/Arrays".equals(namespaceURI) &&
                  "ArrayOfstring".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TimeZone".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TimeZone.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetingGeoLevelTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetingGeoLevelTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfKeywordsInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfKeywordsInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBrowser".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfBrowser.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetedViewer".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetedViewer.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SequenceRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.SequenceRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetAudienceServiceFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetAudienceServiceFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "KeywordsInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.KeywordsInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticOptimizationMethodTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AutomaticOptimizationMethodTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfTargetAudienceServiceFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfTargetAudienceServiceFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBandwidth".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfBandwidth.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "CommercialBreakIntroPositioningType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.CommercialBreakIntroPositioningType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdvertiserFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdvertiserFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfDeliveryGroupInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfDeliveryGroupInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) &&
                  "char".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization._char.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PushDownBannerInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PushDownBannerInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "WallpaperAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.WallpaperAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ExpandableBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ExpandableBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "APIFilterBase".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.DeliveryGroup.APIFilterBase.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "BatchActionError".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.DeliveryGroup.BatchActionError.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DisplayPeriodTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DisplayPeriodTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PanelFrequencyType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PanelFrequencyType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfResolution".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfResolution.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetingTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetingTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastCompanionAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfInStreamVastCompanionAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "StateRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.StateRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdClassificationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdClassificationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetingGeoInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetingGeoInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastNonLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.InStreamVastNonLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SubGroupAutomaticOptimizationRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.SubGroupAutomaticOptimizationRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastCompanionAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.InStreamVastCompanionAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfBasicInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfBasicInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Platform".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.Platform.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "Bandwidth".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.Bandwidth.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "RotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.RotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetAudienceNameFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetAudienceNameFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PanelsEnabledAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PanelsEnabledAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.InStreamVastAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "ArrayOfBatchActionError".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.DeliveryGroup.ArrayOfBatchActionError.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastDeliveryType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.InStreamVastDeliveryType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetAudienceIDFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetAudienceIDFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticOptimizationKeywordInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AutomaticOptimizationKeywordInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliveryGroupsServiceFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliveryGroupsServiceFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfPlatform".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfPlatform.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliveryGroupInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliveryGroupInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SubGroupTimeRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.SubGroupTimeRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetedSiteSegmentationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetedSiteSegmentationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfTimeBasedRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfTimeBasedRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAutomaticOptimizationKeywordInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfAutomaticOptimizationKeywordInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfTargetedViewer".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfTargetedViewer.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "TargetAudienceInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.TargetAudienceInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticOptimizationZipCodeInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AutomaticOptimizationZipCodeInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PlacementTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PlacementTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "MovementTypeSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.MovementTypeSettings.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfInStreamVastLinearAssetInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfInStreamVastLinearAssetInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "StatusFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.StatusFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliverySubGroupRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliverySubGroupRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AccountFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AccountFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "DeliveryGroupDimensionsFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.DeliveryGroupDimensionsFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SubGroupFirsrMatchRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.SubGroupFirsrMatchRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "FloatingAdWithReminderInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.FloatingAdWithReminderInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "WeightRotationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.WeightRotationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "PoliteBannerAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.PoliteBannerAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdditionalAssetsEnabledAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdditionalAssetsEnabledAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticOptimizationInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AutomaticOptimizationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfDeliveryGroupsServiceFilter".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfDeliveryGroupsServiceFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BehavioralTargetingInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.BehavioralTargetingInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/message".equals(namespaceURI) &&
                  "ListPaging".equals(typeName)){
                   
                            return  api.eyeblaster.com.message.DeliveryGroup.ListPaging.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "SingleExpandableAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.SingleExpandableAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) &&
                  "guid".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.Guid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/Arrays".equals(namespaceURI) &&
                  "ArrayOfdouble".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfdouble.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "InStreamVastAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.InStreamVastAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfDeliverySubGroupInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfDeliverySubGroupInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) &&
                  "duration".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.Duration.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AdPositioningType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AdPositioningType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "AutomaticOptimizationLevelTypes".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.AutomaticOptimizationLevelTypes.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "BannerPositionType".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.BannerPositionType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "ArrayOfAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.ArrayOfAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/2003/10/Serialization/Arrays".equals(namespaceURI) &&
                  "ArrayOfboolean".equals(typeName)){
                   
                            return  com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfboolean.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "FloatingAdInfo".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.FloatingAdInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "JobStatus".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.JobStatus.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://api.eyeblaster.com/V1/DataContracts".equals(namespaceURI) &&
                  "VerticalPositionSettings".equals(typeName)){
                   
                            return  api.eyeblaster.com.V1.DataContracts.DeliveryGroup.VerticalPositionSettings.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    