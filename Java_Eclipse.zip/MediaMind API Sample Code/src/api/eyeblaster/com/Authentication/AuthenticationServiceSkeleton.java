
/**
 * AuthenticationServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:24:30 EDT)
 */
    package api.eyeblaster.com.Authentication;
    /**
     *  AuthenticationServiceSkeleton java skeleton for the axisService
     */
    public class AuthenticationServiceSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param clientImpersonation
         */
        
                 public api.eyeblaster.com.Authentication.ClientImpersonationResponse ClientImpersonation
                  (
                  api.eyeblaster.com.Authentication.ClientImpersonation clientImpersonation
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#ClientImpersonation");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param clientLogin
         */
        
                 public api.eyeblaster.com.Authentication.ClientLoginResponse ClientLogin
                  (
                  api.eyeblaster.com.Authentication.ClientLogin clientLogin
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#ClientLogin");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getClientInfoRequest
         */
        
                 public api.eyeblaster.com.message.Authentication.GetClientInfoResponse GetClientInfo
                  (
                  api.eyeblaster.com.message.Authentication.GetClientInfoRequest getClientInfoRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetClientInfo");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param clientLogout
         */
        
                 public api.eyeblaster.com.Authentication.ClientLogoutResponse ClientLogout
                  (
                  api.eyeblaster.com.Authentication.ClientLogout clientLogout
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#ClientLogout");
        }
     
    }
    