
/**
 * AdServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:24:30 EDT)
 */
    package api.eyeblaster.com.Ad;
    /**
     *  AdServiceSkeleton java skeleton for the axisService
     */
    public class AdServiceSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdSpecificFiltersRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdSpecificFiltersResponse GetAdFilters
                  (
                  api.eyeblaster.com.message.Ad.GetAdSpecificFiltersRequest getAdSpecificFiltersRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdFilters");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getPlacementsOfAdRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetPlacementsOfAdResponse GetPlacementsOfAd
                  (
                  api.eyeblaster.com.message.Ad.GetPlacementsOfAdRequest getPlacementsOfAdRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetPlacementsOfAd");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAdClassificationRequest
         */
        
                 public api.eyeblaster.com.message.Ad.CreateAdClassificationResponse CreateAdClassification
                  (
                  api.eyeblaster.com.message.Ad.CreateAdClassificationRequest createAdClassificationRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateAdClassification");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdResponse GetAd
                  (
                  api.eyeblaster.com.message.Ad.GetAdRequest getAdRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAd");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteInStreamVastAssetsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.DeleteInStreamVastElementResponse DeleteInStreamVastAssets
                  (
                  api.eyeblaster.com.message.Ad.DeleteInStreamVastAssetsRequest deleteInStreamVastAssetsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteInStreamVastAssets");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAd3RdPartyTrackingURLRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAd3RdPartyTrackingURLResponse GetAd3PartyTrackingURLById
                  (
                  api.eyeblaster.com.message.Ad.GetAd3RdPartyTrackingURLRequest getAd3RdPartyTrackingURLRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAd3PartyTrackingURLById");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAdResponse UpdateAd
                  (
                  api.eyeblaster.com.message.Ad.UpdateAdRequest updateAdRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAd");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdInteractionsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAdInteractionsResponse UpdateAdInteractions
                  (
                  api.eyeblaster.com.message.Ad.UpdateAdInteractionsRequest updateAdInteractionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAdInteractions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdAdditionalAssetRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAdAdditionalAssetResponse UpdateAdAdditionalAsset
                  (
                  api.eyeblaster.com.message.Ad.UpdateAdAdditionalAssetRequest updateAdAdditionalAssetRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAdAdditionalAsset");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdsBasicInfoRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdsBasicInfoResponse GetAdsBasicInfo
                  (
                  api.eyeblaster.com.message.Ad.GetAdsBasicInfoRequest getAdsBasicInfoRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdsBasicInfo");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryObjectsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetHistoryObjectsResponse GetAdHistoryObjects
                  (
                  api.eyeblaster.com.message.Ad.GetHistoryObjectsRequest getHistoryObjectsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdHistoryObjects");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getPreviewLinksRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetPreviewLinksResponse GetPreviewLinks
                  (
                  api.eyeblaster.com.message.Ad.GetPreviewLinksRequest getPreviewLinksRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetPreviewLinks");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteAdAdditionalAssetRequest
         */
        
                 public void DeleteAdAdditionalAsset
                  (
                  api.eyeblaster.com.message.Ad.DeleteAdAdditionalAssetRequest deleteAdAdditionalAssetRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdPanelRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAdPanelResponse UpdateAdPanel
                  (
                  api.eyeblaster.com.message.Ad.UpdateAdPanelRequest updateAdPanelRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAdPanel");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param duplicateAdRequest
         */
        
                 public api.eyeblaster.com.message.Ad.DuplicateAdReponse DuplicateAd
                  (
                  api.eyeblaster.com.message.Ad.DuplicateAdRequest duplicateAdRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DuplicateAd");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteAd3RdPartyTrackingURLRequest
         */
        
                 public api.eyeblaster.com.message.Ad.DeleteAd3RdPartyTrackingURLResponse DeleteAd3PartyTrackingURLById
                  (
                  api.eyeblaster.com.message.Ad.DeleteAd3RdPartyTrackingURLRequest deleteAd3RdPartyTrackingURLRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteAd3PartyTrackingURLById");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteAdApprovalRemarkRequest
         */
        
                 public api.eyeblaster.com.message.Ad.DeleteAdApprovalRemarkResponse DeleteNotes
                  (
                  api.eyeblaster.com.message.Ad.DeleteAdApprovalRemarkRequest deleteAdApprovalRemarkRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteNotes");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param rejectAdsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.RejectAdsResponse RejectAds
                  (
                  api.eyeblaster.com.message.Ad.RejectAdsRequest rejectAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#RejectAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAdAdditionalAssetRequest
         */
        
                 public api.eyeblaster.com.message.Ad.CreateAdAdditionalAssetResponse CreateAdAdditionalAsset
                  (
                  api.eyeblaster.com.message.Ad.CreateAdAdditionalAssetRequest createAdAdditionalAssetRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateAdAdditionalAsset");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCategoriesRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetCategoriesResponse GetAllCategories
                  (
                  api.eyeblaster.com.message.Ad.GetCategoriesRequest getCategoriesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAllCategories");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteInStreamVastCompanionAdsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.DeleteInStreamVastElementResponse DeleteInStreamVastCompanionAds
                  (
                  api.eyeblaster.com.message.Ad.DeleteInStreamVastCompanionAdsRequest deleteInStreamVastCompanionAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteInStreamVastCompanionAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param attachAdsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.AttachAdsResponse AttachAds
                  (
                  api.eyeblaster.com.message.Ad.AttachAdsRequest attachAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#AttachAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdPanelsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdPanelsResponse GetAdPanels
                  (
                  api.eyeblaster.com.message.Ad.GetAdPanelsRequest getAdPanelsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdPanels");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAd3RdPartyTrackingURLRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAd3RdPartyTrackingURLResponse UpdateAd3PartyTrackingURL
                  (
                  api.eyeblaster.com.message.Ad.UpdateAd3RdPartyTrackingURLRequest updateAd3RdPartyTrackingURLRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAd3PartyTrackingURL");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAgenciesOfAdRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAgenciesOfAdResponse GetAgenciesOfAd
                  (
                  api.eyeblaster.com.message.Ad.GetAgenciesOfAdRequest getAgenciesOfAdRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAgenciesOfAd");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteAdPanelRequest
         */
        
                 public void DeleteAdPanel
                  (
                  api.eyeblaster.com.message.Ad.DeleteAdPanelRequest deleteAdPanelRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAdCustomLogRequest
         */
        
                 public void CreateAdCustomLog
                  (
                  api.eyeblaster.com.message.Ad.CreateAdCustomLogRequest createAdCustomLogRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdAdditionalAssetsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdAdditionalAssetsResponse GetAdAdditionalAssets
                  (
                  api.eyeblaster.com.message.Ad.GetAdAdditionalAssetsRequest getAdAdditionalAssetsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdAdditionalAssets");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAdRequest
         */
        
                 public api.eyeblaster.com.message.Ad.CreateAdResponse CreateAd
                  (
                  api.eyeblaster.com.message.Ad.CreateAdRequest createAdRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateAd");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAdApprovalRemarkRequest
         */
        
                 public api.eyeblaster.com.message.Ad.CreateAdApprovalRemarkResponse CreateNote
                  (
                  api.eyeblaster.com.message.Ad.CreateAdApprovalRemarkRequest createAdApprovalRemarkRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateNote");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteAdsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.DeleteAdsResponse DeleteAds
                  (
                  api.eyeblaster.com.message.Ad.DeleteAdsRequest deleteAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdClassificationRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAdClassificationResponse UpdateAdClassification
                  (
                  api.eyeblaster.com.message.Ad.UpdateAdClassificationRequest updateAdClassificationRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAdClassification");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryActionsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetHistoryActionsResponse GetAdHistoryActions
                  (
                  api.eyeblaster.com.message.Ad.GetHistoryActionsRequest getHistoryActionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdHistoryActions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAdsResponse UpdateAds
                  (
                  api.eyeblaster.com.message.Ad.UpdateAdsRequest updateAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAd3RdPartyTrackingURLsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAd3RdPartyTrackingURLsResponse GetAd3PartyTrackingURLsByAdId
                  (
                  api.eyeblaster.com.message.Ad.GetAd3RdPartyTrackingURLsRequest getAd3RdPartyTrackingURLsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAd3PartyTrackingURLsByAdId");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdClassificationRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdClassificationResponse GetAdClassification
                  (
                  api.eyeblaster.com.message.Ad.GetAdClassificationRequest getAdClassificationRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdClassification");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdHistoryRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetHistoryResponse GetAdHistory
                  (
                  api.eyeblaster.com.message.Ad.GetAdHistoryRequest getAdHistoryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdHistory");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCampaignsOfAdRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetCampaignsOfAdResponse GetCampaignsOfAd
                  (
                  api.eyeblaster.com.message.Ad.GetCampaignsOfAdRequest getCampaignsOfAdRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCampaignsOfAd");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdPanelRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdPanelResponse GetAdPanel
                  (
                  api.eyeblaster.com.message.Ad.GetAdPanelRequest getAdPanelRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdPanel");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param publishAdsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.PublishAdsResponse PublishAds
                  (
                  api.eyeblaster.com.message.Ad.PublishAdsRequest publishAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#PublishAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdsResponse GetAds
                  (
                  api.eyeblaster.com.message.Ad.GetAdsRequest getAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdFiltersRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdFiltersResponse GetAvailableFilters
                  (
                  api.eyeblaster.com.message.Ad.GetAdFiltersRequest getAdFiltersRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAvailableFilters");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdInteractionsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdInteractionsResponse GetAdInteractions
                  (
                  api.eyeblaster.com.message.Ad.GetAdInteractionsRequest getAdInteractionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdInteractions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdAdditionalAssetRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdAdditionalAssetResponse GetAdAdditionalAsset
                  (
                  api.eyeblaster.com.message.Ad.GetAdAdditionalAssetRequest getAdAdditionalAssetRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdAdditionalAsset");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param setDefaultPanelRequest
         */
        
                 public api.eyeblaster.com.message.Ad.SetDefaultPanelResponse SetDefaultPanel
                  (
                  api.eyeblaster.com.message.Ad.SetDefaultPanelRequest setDefaultPanelRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#SetDefaultPanel");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCategoryRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdCategoryResponse GetCategory
                  (
                  api.eyeblaster.com.message.Ad.GetCategoryRequest getCategoryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCategory");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param setAdFiltersRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdSpecificFiltersResponse SetAdFilters
                  (
                  api.eyeblaster.com.message.Ad.SetAdFiltersRequest setAdFiltersRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#SetAdFilters");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAdPanelRequest
         */
        
                 public api.eyeblaster.com.message.Ad.CreateAdPanelResponse CreateAdPanel
                  (
                  api.eyeblaster.com.message.Ad.CreateAdPanelRequest createAdPanelRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateAdPanel");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdApprovalRemarkRequest
         */
        
                 public api.eyeblaster.com.message.Ad.UpdateAdApprovalRemarkResponse UpdateNote
                  (
                  api.eyeblaster.com.message.Ad.UpdateAdApprovalRemarkRequest updateAdApprovalRemarkRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateNote");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAd3RdPartyTrackingURLRequest
         */
        
                 public api.eyeblaster.com.message.Ad.CreateAd3RdPartyTrackingURLResponse CreateAd3PartyTrackingURL
                  (
                  api.eyeblaster.com.message.Ad.CreateAd3RdPartyTrackingURLRequest createAd3RdPartyTrackingURLRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateAd3PartyTrackingURL");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteAd3RdPartyTrackingURLsRequest
         */
        
                 public api.eyeblaster.com.message.Ad.DeleteAd3RdPartyTrackingURLResponse DeleteAd3PartyTrackingURLsByAdId
                  (
                  api.eyeblaster.com.message.Ad.DeleteAd3RdPartyTrackingURLsRequest deleteAd3RdPartyTrackingURLsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteAd3PartyTrackingURLsByAdId");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdApprovalRemarksRequest
         */
        
                 public api.eyeblaster.com.message.Ad.GetAdApprovalRemarksResponse GetNotes
                  (
                  api.eyeblaster.com.message.Ad.GetAdApprovalRemarksRequest getAdApprovalRemarksRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetNotes");
        }
     
    }
    