
/**
 * DeliveryGroupServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:24:30 EDT)
 */
    package api.eyeblaster.com.DeliveryGroup;
    /**
     *  DeliveryGroupServiceSkeleton java skeleton for the axisService
     */
    public class DeliveryGroupServiceSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCitiesByRegionRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetCitiesByCountryResponse GetCitiesByRegion
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetCitiesByRegionRequest getCitiesByRegionRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCitiesByRegion");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createDeliveryGroupRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.CreateDeliveryGroupResponse CreateDeliveryGroup
                  (
                  api.eyeblaster.com.message.DeliveryGroup.CreateDeliveryGroupRequest createDeliveryGroupRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateDeliveryGroup");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getBehavioralTargetingsBySiteIDRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetBehavioralTargetingsBySiteIDResponse GetBehavioralTargetingsBySiteID
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetBehavioralTargetingsBySiteIDRequest getBehavioralTargetingsBySiteIDRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetBehavioralTargetingsBySiteID");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDeliverySubGroupMasterAdsRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDeliverySubGroupMasterAdsResponse GetDeliverySubGroupMasterAds
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDeliverySubGroupMasterAdsRequest getDeliverySubGroupMasterAdsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDeliverySubGroupMasterAds");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDeliveryGroupRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupResponse GetDeliveryGroup
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupRequest getDeliveryGroupRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDeliveryGroup");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateDeliveryGroupRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.UpdateDeliveryGroupResponse UpdateDeliveryGroup
                  (
                  api.eyeblaster.com.message.DeliveryGroup.UpdateDeliveryGroupRequest updateDeliveryGroupRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateDeliveryGroup");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getMasterAdByCampaignRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetMasterAdByCampaignResponse GetMasterAdByCampaign
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetMasterAdByCampaignRequest getMasterAdByCampaignRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetMasterAdByCampaign");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDeliverySubGroupsRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDeliverySubGroupsResponse GetDeliverySubGroups
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDeliverySubGroupsRequest getDeliverySubGroupsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDeliverySubGroups");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createMsnAgerValuesRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.CreateMsnAgerValuesResponse CreateMsnAgerValues
                  (
                  api.eyeblaster.com.message.DeliveryGroup.CreateMsnAgerValuesRequest createMsnAgerValuesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateMsnAgerValues");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createTargetAudienceRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.CreateTargetAudienceResponse CreateTargetAudience
                  (
                  api.eyeblaster.com.message.DeliveryGroup.CreateTargetAudienceRequest createTargetAudienceRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateTargetAudience");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getMasterAdByDeliveryGroupRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetMasterAdByDeliveryGroupResponse GetMasterAdByDeliveryGroup
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetMasterAdByDeliveryGroupRequest getMasterAdByDeliveryGroupRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetMasterAdByDeliveryGroup");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdvertisersRetargetingTagsRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetAdvertisersRetargetingTagsResponse GetAdvertisersRetargetingTags
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetAdvertisersRetargetingTagsRequest getAdvertisersRetargetingTagsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdvertisersRetargetingTags");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param changeStateMasterAdOnDeliveryGroupRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.ChangeStateMasterAdOnDeliveryGroupResponse ChangeStateMasterAdOnDeliveryGroup
                  (
                  api.eyeblaster.com.message.DeliveryGroup.ChangeStateMasterAdOnDeliveryGroupRequest changeStateMasterAdOnDeliveryGroupRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#ChangeStateMasterAdOnDeliveryGroup");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAreaCodesByCountryRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetAreaCodesByCountryResponse GetAreaCodesByCountry
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetAreaCodesByCountryRequest getAreaCodesByCountryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAreaCodesByCountry");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteDeliveryGroupRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.DeleteDeliveryGroupResponse DeleteDeliveryGroup
                  (
                  api.eyeblaster.com.message.DeliveryGroup.DeleteDeliveryGroupRequest deleteDeliveryGroupRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteDeliveryGroup");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDeliveryGroupFrequencyCappingRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupFrequencyCappingResponse GetDeliveryGroupFrequencyCapping
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupFrequencyCappingRequest getDeliveryGroupFrequencyCappingRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDeliveryGroupFrequencyCapping");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getMsnAgeValuesRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetMsnAgeValuesResponse GetMsnAgeValues
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetMsnAgeValuesRequest getMsnAgeValuesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetMsnAgeValues");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDeliverySubGroupRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDeliverySubGroupResponse GetDeliverySubGroup
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDeliverySubGroupRequest getDeliverySubGroupRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDeliverySubGroup");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getPublisherSegmentationSitesRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetPublisherSegmentationSitesResponse GetPublisherSegmentationSites
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetPublisherSegmentationSitesRequest getPublisherSegmentationSitesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetPublisherSegmentationSites");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDMAByCountryRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDMAByCountryResponse GetDMAByCountry
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDMAByCountryRequest getDMAByCountryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDMAByCountry");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getMasterAdsByPlacementRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetMasterAdsByPlacementResponse GetMasterAdsByPlacement
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetMasterAdsByPlacementRequest getMasterAdsByPlacementRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetMasterAdsByPlacement");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getPublisherSegmentationSitePropertiesRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetPublisherSegmentationSitePropertiesResponse GetPublisherSegmentationSiteProperties
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetPublisherSegmentationSitePropertiesRequest getPublisherSegmentationSitePropertiesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetPublisherSegmentationSiteProperties");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDMAsByRegionRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDMAsByRegionResponse GetDMAByRegions
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDMAsByRegionRequest getDMAsByRegionRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDMAByRegions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAreaCodesByRegionRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetAreaCodesByRegionResponse GetAreaCodesByRegion
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetAreaCodesByRegionRequest getAreaCodesByRegionRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAreaCodesByRegion");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDeliveryGroupsByPlacementIDRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupsByPlacementIDResponse GetDeliveryGroupsByPlacementID
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupsByPlacementIDRequest getDeliveryGroupsByPlacementIDRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDeliveryGroupsByPlacementID");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCountriesRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetCountriesResponse GetCountries
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetCountriesRequest getCountriesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCountries");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param attachDeliveryGroupToPlacementRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.AttachDeliveryGroupToPlacementResponse AttachDeliveryGroupToPlacement
                  (
                  api.eyeblaster.com.message.DeliveryGroup.AttachDeliveryGroupToPlacementRequest attachDeliveryGroupToPlacementRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#AttachDeliveryGroupToPlacement");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param attachMasterAdToPlacementRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.AttachMasterAdToPlacementResponse AttachMasterAdToPlacement
                  (
                  api.eyeblaster.com.message.DeliveryGroup.AttachMasterAdToPlacementRequest attachMasterAdToPlacementRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#AttachMasterAdToPlacement");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param setDeliveryGroupFrequencyCappingRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.SetDeliveryGroupFrequencyCappingResponse SetDeliveryGroupFrequencyCapping
                  (
                  api.eyeblaster.com.message.DeliveryGroup.SetDeliveryGroupFrequencyCappingRequest setDeliveryGroupFrequencyCappingRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#SetDeliveryGroupFrequencyCapping");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getRegionsByCountryRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetRegionsByCountryResponse GetRegionsByCountry
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetRegionsByCountryRequest getRegionsByCountryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetRegionsByCountry");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getTargetAudiencesRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetTargetAudiencesResponse GetTargetAudiences
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetTargetAudiencesRequest getTargetAudiencesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetTargetAudiences");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCitiesByCountryRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetCitiesByCountryResponse GetCitiesByCountry
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetCitiesByCountryRequest getCitiesByCountryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCitiesByCountry");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getDeliveryGroupsRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupsResponse GetDeliveryGroups
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetDeliveryGroupsRequest getDeliveryGroupsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetDeliveryGroups");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteTargetAudienceRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.DeleteTargetAudienceResponse DeleteTargetAudience
                  (
                  api.eyeblaster.com.message.DeliveryGroup.DeleteTargetAudienceRequest deleteTargetAudienceRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteTargetAudience");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAttachJobStatusRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.GetAttachJobStatusResponse CheckJobStatus
                  (
                  api.eyeblaster.com.message.DeliveryGroup.GetAttachJobStatusRequest getAttachJobStatusRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CheckJobStatus");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateTargetAudienceRequest
         */
        
                 public api.eyeblaster.com.message.DeliveryGroup.UpdateTargetAudienceResponse UpdateTargetAudience
                  (
                  api.eyeblaster.com.message.DeliveryGroup.UpdateTargetAudienceRequest updateTargetAudienceRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateTargetAudience");
        }
     
    }
    