
/**
 * AdvertiserServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:24:30 EDT)
 */
    package api.eyeblaster.com.Advertiser;
    /**
     *  AdvertiserServiceSkeleton java skeleton for the axisService
     */
    public class AdvertiserServiceSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param getMarketsRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetMarketsResponse GetMarkets
                  (
                  api.eyeblaster.com.message.Advertiser.GetMarketsRequest getMarketsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetMarkets");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateConversionTagTypeRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.UpdateConversionTagTypeResponse UpdateConversionTagType
                  (
                  api.eyeblaster.com.message.Advertiser.UpdateConversionTagTypeRequest updateConversionTagTypeRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateConversionTagType");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteBrandRequest
         */
        
                 public void DeleteBrand
                  (
                  api.eyeblaster.com.message.Advertiser.DeleteBrandRequest deleteBrandRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createConversionTagsRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.CreateConversionTagsResponse CreateConversionTags
                  (
                  api.eyeblaster.com.message.Advertiser.CreateConversionTagsRequest createConversionTagsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateConversionTags");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createBrandRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.CreateBrandResponse CreateBrand
                  (
                  api.eyeblaster.com.message.Advertiser.CreateBrandRequest createBrandRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateBrand");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getConversionTagThirdPartyRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetConversionTagsThirdPartyResponse GetConversionTagsThirdParty
                  (
                  api.eyeblaster.com.message.Advertiser.GetConversionTagThirdPartyRequest getConversionTagThirdPartyRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetConversionTagsThirdParty");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteAdvertiserRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.DeleteAdvertiserResponse DeleteAdvertiser
                  (
                  api.eyeblaster.com.message.Advertiser.DeleteAdvertiserRequest deleteAdvertiserRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteAdvertiser");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateBrandRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.UpdateBrandResponse UpdateBrand
                  (
                  api.eyeblaster.com.message.Advertiser.UpdateBrandRequest updateBrandRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateBrand");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getOfficesRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetOfficesResponse GetOffices
                  (
                  api.eyeblaster.com.message.Advertiser.GetOfficesRequest getOfficesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetOffices");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryActionsRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetHistoryActionsResponse GetAdvertiserHistoryActions
                  (
                  api.eyeblaster.com.message.Advertiser.GetHistoryActionsRequest getHistoryActionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdvertiserHistoryActions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createConversionTagRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.CreateConversionTagResponse CreateConversionTag
                  (
                  api.eyeblaster.com.message.Advertiser.CreateConversionTagRequest createConversionTagRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateConversionTag");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateAdvertiserRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.UpdateAdvertiserResponse UpdateAdvertiser
                  (
                  api.eyeblaster.com.message.Advertiser.UpdateAdvertiserRequest updateAdvertiserRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateAdvertiser");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteConversionTagThirdPartyRequest
         */
        
                 public void DeleteConversionTagThirdParty
                  (
                  api.eyeblaster.com.message.Advertiser.DeleteConversionTagThirdPartyRequest deleteConversionTagThirdPartyRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryObjectsRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetHistoryObjectsResponse GetAdvertiserHistoryObjects
                  (
                  api.eyeblaster.com.message.Advertiser.GetHistoryObjectsRequest getHistoryObjectsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdvertiserHistoryObjects");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCurrenciesRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetCurrenciesResponse GetCurrencies
                  (
                  api.eyeblaster.com.message.Advertiser.GetCurrenciesRequest getCurrenciesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCurrencies");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createAdvertiserRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.CreateAdvertiserResponse CreateAdvertiser
                  (
                  api.eyeblaster.com.message.Advertiser.CreateAdvertiserRequest createAdvertiserRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateAdvertiser");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getBrandsRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetBrandsResponse GetBrands
                  (
                  api.eyeblaster.com.message.Advertiser.GetBrandsRequest getBrandsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetBrands");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteConversionTagsRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.DeleteConversionTagsResponse DeleteConversionTags
                  (
                  api.eyeblaster.com.message.Advertiser.DeleteConversionTagsRequest deleteConversionTagsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteConversionTags");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateConversionTagRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.UpdateConversionTagResponse UpdateConversionTag
                  (
                  api.eyeblaster.com.message.Advertiser.UpdateConversionTagRequest updateConversionTagRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateConversionTag");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param conversionTagCodeRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.ConversionTagCodeResponse GetConversionTagCode
                  (
                  api.eyeblaster.com.message.Advertiser.ConversionTagCodeRequest conversionTagCodeRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetConversionTagCode");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createConversionTagThirdPartyRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.CreateConversionTagThirdPartyResponse CreateConversionTagThirdParty
                  (
                  api.eyeblaster.com.message.Advertiser.CreateConversionTagThirdPartyRequest createConversionTagThirdPartyRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateConversionTagThirdParty");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getConversionTagsRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetConversionTagsResponse GetConversionTags
                  (
                  api.eyeblaster.com.message.Advertiser.GetConversionTagsRequest getConversionTagsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetConversionTags");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdvertisersRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetAdvertisersResponse GetAdvertisers
                  (
                  api.eyeblaster.com.message.Advertiser.GetAdvertisersRequest getAdvertisersRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdvertisers");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getAdvertiserHistoryRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetHistoryResponse GetAdvertiserHistory
                  (
                  api.eyeblaster.com.message.Advertiser.GetAdvertiserHistoryRequest getAdvertiserHistoryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetAdvertiserHistory");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateConversionTagThirdPartyRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.UpdateConversionTagThirdPartyResponse UpdateConversionTagThirdParty
                  (
                  api.eyeblaster.com.message.Advertiser.UpdateConversionTagThirdPartyRequest updateConversionTagThirdPartyRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateConversionTagThirdParty");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getSitesRequest
         */
        
                 public api.eyeblaster.com.message.Advertiser.GetSitesResponse GetSites
                  (
                  api.eyeblaster.com.message.Advertiser.GetSitesRequest getSitesRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetSites");
        }
     
    }
    