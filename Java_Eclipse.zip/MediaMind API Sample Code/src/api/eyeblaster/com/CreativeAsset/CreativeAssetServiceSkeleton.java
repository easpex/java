
/**
 * CreativeAssetServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4  Built on : Apr 26, 2008 (06:24:30 EDT)
 */
    package api.eyeblaster.com.CreativeAsset;
    /**
     *  CreativeAssetServiceSkeleton java skeleton for the axisService
     */
    public class CreativeAssetServiceSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteCreativeAssetsRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.DeleteCreativeAssetsResponse DeleteCreativeAssets
                  (
                  api.eyeblaster.com.message.CreativeAsset.DeleteCreativeAssetsRequest deleteCreativeAssetsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#DeleteCreativeAssets");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param deleteFolderRequest
         */
        
                 public void DeleteFolder
                  (
                  api.eyeblaster.com.message.CreativeAsset.DeleteFolderRequest deleteFolderRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param requestBase
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetFolderResponse GetRootFolder
                  (
                  api.eyeblaster.com.message.CreativeAsset.RequestBase requestBase
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetRootFolder");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateFolderRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.UpdateFolderResponse UpdateFolder
                  (
                  api.eyeblaster.com.message.CreativeAsset.UpdateFolderRequest updateFolderRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateFolder");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createFolderRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.CreateFolderResponse CreateFolder
                  (
                  api.eyeblaster.com.message.CreativeAsset.CreateFolderRequest createFolderRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateFolder");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCreativeAssetsRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetCreativeAssetsResponse GetCreativeAssets
                  (
                  api.eyeblaster.com.message.CreativeAsset.GetCreativeAssetsRequest getCreativeAssetsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeAssets");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param updateCreativeAssetRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.UpdateCreativeAssetResponse UpdateCreativeAsset
                  (
                  api.eyeblaster.com.message.CreativeAsset.UpdateCreativeAssetRequest updateCreativeAssetRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#UpdateCreativeAsset");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param requestBase7
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetFolderIDResponse GetRootFolderID
                  (
                  api.eyeblaster.com.message.CreativeAsset.RequestBase requestBase7
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetRootFolderID");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getFolderNameRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetFoldersResponse GetFoldersByName
                  (
                  api.eyeblaster.com.message.CreativeAsset.GetFolderNameRequest getFolderNameRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetFoldersByName");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryActionsRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetHistoryActionsResponse GetCreativeAssetHistoryActions
                  (
                  api.eyeblaster.com.message.CreativeAsset.GetHistoryActionsRequest getHistoryActionsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeAssetHistoryActions");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getHistoryObjectsRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetHistoryObjectsResponse GetCreativeAssetHistoryObjects
                  (
                  api.eyeblaster.com.message.CreativeAsset.GetHistoryObjectsRequest getHistoryObjectsRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeAssetHistoryObjects");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param createCreativeAssetRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.CreateCreativeAssetResponse CreateCreativeAsset
                  (
                  api.eyeblaster.com.message.CreativeAsset.CreateCreativeAssetRequest createCreativeAssetRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#CreateCreativeAsset");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCreativeAssetHistoryRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetHistoryResponse GetCreativeAssetHistory
                  (
                  api.eyeblaster.com.message.CreativeAsset.GetCreativeAssetHistoryRequest getCreativeAssetHistoryRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeAssetHistory");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getFolderRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetFolderResponse GetFolder
                  (
                  api.eyeblaster.com.message.CreativeAsset.GetFolderRequest getFolderRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetFolder");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param requestBase16
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetCreativeAssetTypeResponse GetCreativeAssetAvailableType
                  (
                  api.eyeblaster.com.message.CreativeAsset.RequestBase requestBase16
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeAssetAvailableType");
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param getCreativeAssetRequest
         */
        
                 public api.eyeblaster.com.message.CreativeAsset.GetCreativeAssetResponse GetCreativeAsset
                  (
                  api.eyeblaster.com.message.CreativeAsset.GetCreativeAssetRequest getCreativeAssetRequest
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#GetCreativeAsset");
        }
     
    }
    